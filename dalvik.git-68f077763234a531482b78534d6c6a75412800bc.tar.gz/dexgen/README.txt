Home of dexgen, the dex code generator project. It provides API for
creating dex classes in runtime which is needed e.g. for class mocking.
This solution is based on the dx tool and uses its classes extensively.
